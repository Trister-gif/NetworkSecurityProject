# 命中：python-code-scanning.qls > CommandInjection
from flask import Flask, request
import os
app = Flask(__name__)

@app.route("/run")
def run():
    cmd = request.args.get("cmd", "echo 123")
    return os.system(cmd)          # ❗ 直接拼接用户输入 → CommandInjection
if __name__ == '__main__':
    app.run(debug=True)